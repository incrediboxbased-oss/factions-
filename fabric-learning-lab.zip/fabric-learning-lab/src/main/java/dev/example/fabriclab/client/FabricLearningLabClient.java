package dev.example.fabriclab.client;

import dev.example.fabriclab.FabricLearningLab;
import dev.example.fabriclab.network.DemoAckPayload;
import dev.example.fabriclab.network.DemoRequestPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.concurrent.atomic.AtomicInteger;

public final class FabricLearningLabClient implements ClientModInitializer {
    private static final AtomicInteger NEXT_SEQUENCE = new AtomicInteger();
    private static KeyBinding toggleHudKey, sendRequestKey;
    private static boolean hudEnabled = true;
    private static volatile String networkStatus = "No server response yet";

    @Override public void onInitializeClient() {
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.fabric_learning_lab.toggle_hud",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.fabric_learning_lab"));
        sendRequestKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.fabric_learning_lab.send_demo_request",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.fabric_learning_lab"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleHudKey.wasPressed()) {
                hudEnabled = !hudEnabled;
                FabricLearningLab.LOGGER.info("Client-only HUD toggled: {}", hudEnabled);
            }
            while (sendRequestKey.wasPressed()) sendDemoRequest();
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            if (!hudEnabled) return;
            var client = net.minecraft.client.MinecraftClient.getInstance();
            if (client.player == null) return;
            drawContext.drawText(client.textRenderer, Text.literal("Fabric Learning Lab — client-only HUD"), 8, 8, 0x55FF55, true);
            drawContext.drawText(client.textRenderer, Text.literal("G: server demo request | " + networkStatus), 8, 20, 0xFFFFFF, true);
        });
        ClientPlayNetworking.registerGlobalReceiver(DemoAckPayload.ID, (payload, context) -> context.client().execute(() -> {
            boolean accepted = payload.status() == DemoAckPayload.ACCEPTED;
            networkStatus = accepted ? "server accepted #" + payload.sequence() : "server rejected #" + payload.sequence();
            FabricLearningLab.LOGGER.info("Received server acknowledgement: sequence={}, status={}", payload.sequence(), payload.status());
        }));
        FabricLearningLab.LOGGER.info("Fabric Learning Lab client initialized.");
    }

    private static void sendDemoRequest() {
        if (!ClientPlayNetworking.canSend(DemoRequestPayload.ID)) {
            networkStatus = "server does not support the demo payload";
            FabricLearningLab.LOGGER.info("Demo request not sent: server has not registered the payload channel.");
            return;
        }
        int sequence = NEXT_SEQUENCE.incrementAndGet();
        ClientPlayNetworking.send(new DemoRequestPayload(sequence));
        networkStatus = "sent #" + sequence;
        FabricLearningLab.LOGGER.info("Sent server demo request: sequence={}", sequence);
    }
}
