package dev.example.fabriclab.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record DemoRequestPayload(int sequence) implements CustomPayload {
    public static final Id<DemoRequestPayload> ID = new Id<>(Identifier.of("fabric_learning_lab", "demo_request"));
    public static final PacketCodec<RegistryByteBuf, DemoRequestPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, DemoRequestPayload::sequence, DemoRequestPayload::new);
    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
