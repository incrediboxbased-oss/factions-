package dev.example.fabriclab.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record DemoAckPayload(int sequence, int status) implements CustomPayload {
    public static final int ACCEPTED = 1;
    public static final int REJECTED = 0;
    public static final Id<DemoAckPayload> ID = new Id<>(Identifier.of("fabric_learning_lab", "demo_ack"));
    public static final PacketCodec<RegistryByteBuf, DemoAckPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, DemoAckPayload::sequence,
            PacketCodecs.VAR_INT, DemoAckPayload::status,
            DemoAckPayload::new);
    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
