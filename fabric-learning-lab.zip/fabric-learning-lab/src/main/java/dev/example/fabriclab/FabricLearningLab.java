package dev.example.fabriclab;

import dev.example.fabriclab.network.DemoAckPayload;
import dev.example.fabriclab.network.DemoRequestPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class FabricLearningLab implements ModInitializer {
    public static final String MOD_ID = "fabric_learning_lab";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final long REQUEST_COOLDOWN_MS = 1_500L;
    private static final Map<UUID, Long> LAST_ACCEPTED_REQUEST = new HashMap<>();

    @Override public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(DemoRequestPayload.ID, DemoRequestPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(DemoAckPayload.ID, DemoAckPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(DemoRequestPayload.ID,
                (payload, context) -> context.server().execute(() -> handleRequest(context.player(), payload)));
        LOGGER.info("Fabric Learning Lab initialized; server networking is ready.");
    }

    private static void handleRequest(ServerPlayerEntity player, DemoRequestPayload payload) {
        long now = System.currentTimeMillis();
        UUID playerId = player.getUuid();
        long lastAccepted = LAST_ACCEPTED_REQUEST.getOrDefault(playerId, 0L);
        boolean creativeMode = player.isCreative();
        boolean cooldownPassed = now - lastAccepted >= REQUEST_COOLDOWN_MS;
        boolean accepted = creativeMode && cooldownPassed;
        if (accepted) {
            LAST_ACCEPTED_REQUEST.put(playerId, now);
            ServerWorld world = player.getServerWorld();
            world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0,
                    player.getZ(), 12, 0.3, 0.4, 0.3, 0.01);
        }
        int status = accepted ? DemoAckPayload.ACCEPTED : DemoAckPayload.REJECTED;
        ServerPlayNetworking.send(player, new DemoAckPayload(payload.sequence(), status));
        LOGGER.info("Networking demo request: player={}, sequence={}, creative={}, cooldownPassed={}, accepted={}",
                player.getName().getString(), payload.sequence(), creativeMode, cooldownPassed, accepted);
    }
}
