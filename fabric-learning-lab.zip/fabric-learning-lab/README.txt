Fabric Learning Lab - Minecraft 1.21.1

This archive contains source code only. Build it using Gradle and Java 21.

Suggested Termux steps:
  pkg update && pkg install openjdk-21 gradle
  cd into the extracted folder
  gradle wrapper --gradle-version 8.10.2
  ./gradlew build

The built JAR will be in build/libs.
This demo's G key requires the mod on the server and creative mode.
