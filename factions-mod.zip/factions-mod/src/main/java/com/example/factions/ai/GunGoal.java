package com.example.factions.ai;

import com.example.factions.compat.TaczCompat;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;

/** Стрельба из оружия TaCZ по врагам. Работает для любого моба (жители, солдаты). */
public class GunGoal extends Goal {
    private static final double SEARCH_RANGE = 24.0;
    private static final double SHOOT_RANGE = 22.0;

    private final MobEntity mob;
    private final Predicate<LivingEntity> enemy;
    private final BooleanSupplier canMove;
    private final double speed;

    private LivingEntity target;
    private int cooldown;
    private int reloadTimer;
    private boolean reloading;

    public GunGoal(MobEntity mob, Predicate<LivingEntity> enemy, BooleanSupplier canMove, double speed) {
        this.mob = mob;
        this.enemy = enemy;
        this.canMove = canMove;
        this.speed = speed;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    private boolean holdsGun() {
        return TaczCompat.isGun(mob.getMainHandStack());
    }

    @Override
    public boolean canStart() {
        if (mob.age % 10 != 0 || !holdsGun()) return false;
        Box box = mob.getBoundingBox().expand(SEARCH_RANGE, 8.0, SEARCH_RANGE);
        List<LivingEntity> found = mob.getWorld().getEntitiesByClass(LivingEntity.class, box,
                e -> e != mob && e.isAlive() && enemy.test(e) && mob.canSee(e));
        target = found.stream().min(Comparator.comparingDouble(mob::squaredDistanceTo)).orElse(null);
        return target != null;
    }

    @Override
    public boolean shouldContinue() {
        return target != null && target.isAlive() && holdsGun()
                && mob.squaredDistanceTo(target) < (SEARCH_RANGE + 8) * (SEARCH_RANGE + 8);
    }

    @Override
    public void start() {
        TaczCompat.draw(mob);
        cooldown = 10;
        reloading = false;
    }

    @Override
    public void stop() {
        TaczCompat.aim(mob, false);
        mob.getNavigation().stop();
        target = null;
    }

    @Override
    public boolean shouldRunEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        if (target == null) return;
        ItemStack gun = mob.getMainHandStack();
        double dist = mob.distanceTo(target);
        boolean sees = mob.canSee(target);

        mob.getLookControl().lookAt(target, 30.0f, 30.0f);
        if (canMove.getAsBoolean() && (dist > 16.0 || !sees)) {
            mob.getNavigation().startMovingTo(target, speed);
        } else {
            mob.getNavigation().stop();
        }
        if (!sees || dist > SHOOT_RANGE) {
            TaczCompat.aim(mob, false);
            return;
        }
        TaczCompat.aim(mob, true);

        if (reloading) {
            if (--reloadTimer <= 0) {
                TaczCompat.refill(gun);
                reloading = false;
            }
            return;
        }
        if (TaczCompat.ammo(gun) <= 0) {
            reloading = true;
            reloadTimer = 60;
            return;
        }
        if (cooldown-- > 0) return;

        Vec3d from = mob.getEyePos();
        Vec3d to = target.getPos().add(0, target.getHeight() * 0.7, 0);
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f
                + (float) (mob.getRandom().nextGaussian() * 2.0);
        float pitch = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI)
                + (float) (mob.getRandom().nextGaussian() * 1.5);
        mob.setYaw(yaw);
        mob.setHeadYaw(yaw);
        mob.setBodyYaw(yaw);
        mob.setPitch(pitch);

        TaczCompat.shoot(mob);
        cooldown = 6 + mob.getRandom().nextInt(8);
    }
}
