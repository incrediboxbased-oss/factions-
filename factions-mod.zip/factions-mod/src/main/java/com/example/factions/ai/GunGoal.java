package com.example.factions.ai;

import com.example.factions.compat.TaczCompat;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;

/**
 * Стрельба из оружия TaCZ по врагам. Работает для любого моба (жители, бойцы, рейдеры).
 * Умеет: стрелять очередями, уходить вбок, отступать при опасности, догонять цель,
 * реагировать на ответы TaCZ (не достал оружие, нет патронов, нужно передёрнуть затвор).
 */
public class GunGoal extends Goal {
    private static final double SEARCH_RANGE = 28.0;
    private static final double SHOOT_RANGE = 26.0;

    private final MobEntity mob;
    private final Predicate<LivingEntity> enemy;
    private final BooleanSupplier canMove;
    private final double speed;

    private LivingEntity target;
    private int cooldown;
    private int reloadTimer;
    private boolean reloading;
    private int burstLeft;
    private int strafeTimer;
    private int strafeDir = 1;

    public GunGoal(MobEntity mob, Predicate<LivingEntity> enemy, BooleanSupplier canMove, double speed) {
        this.mob = mob;
        this.enemy = enemy;
        this.canMove = canMove;
        this.speed = speed;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    private boolean holdsGun() {
        return TaczCompat.isGun(mob.getMainHandStack());
    }

    @Override
    public boolean canStart() {
        if (mob.age % 5 != 0 || !holdsGun()) return false;
        Box box = mob.getBoundingBox().expand(SEARCH_RANGE, 10.0, SEARCH_RANGE);
        List<LivingEntity> found = mob.getWorld().getEntitiesByClass(LivingEntity.class, box,
                e -> e != mob && e.isAlive() && enemy.test(e) && mob.canSee(e));
        target = found.stream().min(Comparator.comparingDouble(mob::squaredDistanceTo)).orElse(null);
        return target != null;
    }

    @Override
    public boolean shouldContinue() {
        return target != null && target.isAlive() && holdsGun()
                && mob.squaredDistanceTo(target) < (SEARCH_RANGE + 10) * (SEARCH_RANGE + 10);
    }

    @Override
    public void start() {
        TaczCompat.draw(mob);
        cooldown = 12;
        reloading = false;
        burstLeft = 2 + mob.getRandom().nextInt(4);
        mob.setAttacking(true);
    }

    @Override
    public void stop() {
        TaczCompat.aim(mob, false);
        mob.getNavigation().stop();
        mob.setAttacking(false);
        target = null;
    }

    @Override
    public boolean shouldRunEveryTick() {
        return true;
    }

    private void move(double dist, boolean sees) {
        boolean wounded = mob.getHealth() < mob.getMaxHealth() * 0.3f;
        Vec3d toTarget = target.getPos().subtract(mob.getPos());
        Vec3d flat = new Vec3d(toTarget.x, 0, toTarget.z);
        if (wounded || dist < 6.0) {
            Vec3d away = flat.lengthSquared() < 1.0E-4
                    ? new Vec3d(1, 0, 0) : flat.normalize().multiply(-7.0);
            mob.getNavigation().startMovingTo(mob.getX() + away.x, mob.getY(), mob.getZ() + away.z, speed * 1.2);
        } else if (!sees || dist > 18.0) {
            mob.getNavigation().startMovingTo(target, speed);
        } else if (--strafeTimer <= 0) {
            strafeTimer = 25 + mob.getRandom().nextInt(30);
            strafeDir = mob.getRandom().nextBoolean() ? 1 : -1;
            Vec3d side = new Vec3d(-flat.z, 0, flat.x).normalize().multiply(3.0 * strafeDir);
            mob.getNavigation().startMovingTo(mob.getX() + side.x, mob.getY(), mob.getZ() + side.z, speed);
        }
    }

    @Override
    public void tick() {
        if (target == null) return;
        ItemStack gun = mob.getMainHandStack();
        double dist = mob.distanceTo(target);
        boolean sees = mob.canSee(target);

        // Мозг жителя не должен перебивать бой своими задачами
        if (mob instanceof VillagerEntity v) {
            v.getBrain().forget(MemoryModuleType.WALK_TARGET);
            v.getBrain().forget(MemoryModuleType.LOOK_TARGET);
        }
        mob.setAttacking(true);
        mob.getLookControl().lookAt(target, 40.0f, 40.0f);

        if (canMove.getAsBoolean()) {
            move(dist, sees);
        } else {
            mob.getNavigation().stop();
        }
        if (!sees || dist > SHOOT_RANGE) {
            TaczCompat.aim(mob, false);
            return;
        }
        TaczCompat.aim(mob, true);

        if (reloading) {
            if (--reloadTimer <= 0) {
                TaczCompat.refill(gun);
                reloading = false;
            }
            return;
        }
        if (--cooldown > 0) return;
        if (TaczCompat.ammo(gun) <= 0) {
            reloading = true;
            reloadTimer = 50;
            return;
        }

        // Наводимся: чем дальше цель, тем больше погрешность
        Vec3d from = mob.getEyePos();
        Vec3d to = target.getPos().add(0, target.getHeight() * 0.65, 0);
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double err = 0.8 + dist * 0.06;
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f
                + (float) (mob.getRandom().nextGaussian() * err);
        float pitch = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI)
                + (float) (mob.getRandom().nextGaussian() * err * 0.8);
        mob.setYaw(yaw);
        mob.setHeadYaw(yaw);
        mob.setBodyYaw(yaw);
        mob.setPitch(pitch);

        String result = TaczCompat.shoot(mob);
        switch (result) {
            case "SUCCESS" -> {
                if (--burstLeft <= 0) {
                    burstLeft = 2 + mob.getRandom().nextInt(4);
                    cooldown = 15 + mob.getRandom().nextInt(20); // пауза между очередями
                } else {
                    cooldown = 1;
                }
            }
            case "COOL_DOWN", "IS_RELOADING", "IS_BOLTING" -> cooldown = 1;
            case "NOT_DRAW" -> { TaczCompat.draw(mob); cooldown = 8; }
            case "IS_DRAWING" -> cooldown = 4;
            case "NEED_BOLT" -> { TaczCompat.bolt(mob); cooldown = 10; }
            case "NO_AMMO" -> { reloading = true; reloadTimer = 50; }
            default -> cooldown = 10;
        }
    }
}
