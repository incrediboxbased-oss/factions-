package com.example.factions.mixin.client;

import com.example.factions.compat.TaczCompat;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.VillagerHeldItemFeatureRenderer;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Жители держат пушку стволом вперёд (как в руке игрока), а не «наоборот»,
 * как это выходит у ванильной отрисовки предметов жителя.
 */
@Mixin(VillagerHeldItemFeatureRenderer.class)
public abstract class VillagerHeldItemFeatureRendererMixin {
    @Shadow @Final private HeldItemRenderer heldItemRenderer;

    @Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/LivingEntity;FFFFFF)V",
            at = @At("HEAD"), cancellable = true)
    private void factions$gunForward(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                     LivingEntity entity, float limbAngle, float limbDistance, float tickDelta,
                                     float animationProgress, float headYaw, float headPitch, CallbackInfo ci) {
        ItemStack stack = entity.getEquippedStack(EquipmentSlot.MAINHAND);
        if (!TaczCompat.isGun(stack)) return;

        matrices.push();
        matrices.translate(-0.3, 0.15, 0.0);                                              // правое плечо
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f + headPitch));   // рука вперёд, вслед за взглядом
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f));
        matrices.translate(0.0625, 0.125, -0.625);
        this.heldItemRenderer.renderItem(entity, stack, ModelTransformationMode.THIRD_PERSON_RIGHT_HAND,
                false, matrices, vertexConsumers, light);
        matrices.pop();
        ci.cancel();
    }
}
