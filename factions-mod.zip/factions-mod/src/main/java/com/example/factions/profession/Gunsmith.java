package com.example.factions.profession;

import com.example.factions.FactionsMod;
import com.example.factions.compat.TaczCompat;
import com.google.common.collect.ImmutableSet;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOffers;
import net.minecraft.village.TradedItem;
import net.minecraft.village.VillagerProfession;
import net.minecraft.world.poi.PointOfInterestType;

/**
 * Оружейный стол и профессия «Оружейник»: безработный житель, рядом с которым стоит стол,
 * становится оружейником и торгует пистолетами, ПП, винтовками и патронами.
 */
public final class Gunsmith {
    public static Block TABLE;
    public static VillagerProfession PROFESSION;

    private Gunsmith() {}

    public static void register() {
        Identifier tableId = Identifier.of(FactionsMod.MOD_ID, "gunsmith_table");
        TABLE = Registry.register(Registries.BLOCK, tableId,
                new Block(AbstractBlock.Settings.copy(Blocks.SMITHING_TABLE)));
        Registry.register(Registries.ITEM, tableId, new BlockItem(TABLE, new Item.Settings()));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> entries.add(TABLE));

        PointOfInterestHelper.register(tableId, 1, 1, TABLE);
        RegistryKey<PointOfInterestType> poiKey = RegistryKey.of(RegistryKeys.POINT_OF_INTEREST_TYPE, tableId);
        PROFESSION = Registry.register(Registries.VILLAGER_PROFESSION,
                Identifier.of(FactionsMod.MOD_ID, "gunsmith"),
                new VillagerProfession("gunsmith",
                        entry -> entry.matchesKey(poiKey),
                        entry -> entry.matchesKey(poiKey),
                        ImmutableSet.of(), ImmutableSet.of(),
                        SoundEvents.ENTITY_VILLAGER_WORK_WEAPONSMITH));

        TradeOfferHelper.registerVillagerOffers(PROFESSION, 1, f -> {
            f.add(new TradeOffers.BuyItemFactory(Items.IRON_INGOT, 10, 12, 2));
            f.add(ammo(3));
        });
        TradeOfferHelper.registerVillagerOffers(PROFESSION, 2, f -> {
            f.add(gun(16, "pistol"));
            f.add(ammo(3));
        });
        TradeOfferHelper.registerVillagerOffers(PROFESSION, 3, f -> {
            f.add(gun(26, "smg"));
            f.add(ammo(3));
        });
        TradeOfferHelper.registerVillagerOffers(PROFESSION, 4, f -> {
            f.add(gun(38, "rifle"));
            f.add(ammo(4));
        });
        TradeOfferHelper.registerVillagerOffers(PROFESSION, 5, f -> {
            f.add(gun(45, "rifle"));
            f.add(gun(30, "smg"));
        });
    }

    private static TradeOffers.Factory gun(int emeralds, String type) {
        return (entity, random) -> {
            ItemStack gun = TaczCompat.createGunOfTypes(random, type);
            if (gun.isEmpty()) return null;
            return new TradeOffer(new TradedItem(Items.EMERALD, emeralds), gun, 3, 15, 0.05f);
        };
    }

    private static TradeOffers.Factory ammo(int emeralds) {
        return (entity, random) -> {
            ItemStack ammo = TaczCompat.createAmmoOfTypes(random, 30, "pistol", "smg", "rifle");
            if (ammo.isEmpty()) return null;
            return new TradeOffer(new TradedItem(Items.EMERALD, emeralds), ammo, 12, 4, 0.05f);
        };
    }
}
