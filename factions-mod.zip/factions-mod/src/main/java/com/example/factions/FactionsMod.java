package com.example.factions;

import com.example.factions.ai.GunGoal;
import com.example.factions.compat.TaczCompat;
import com.example.factions.entity.SoldierEntity;
import com.example.factions.item.RecruitOrderItem;
import com.example.factions.mixin.MobEntityAccessor;
import com.example.factions.squad.SquadCommands;
import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.RaiderEntity;
import net.minecraft.entity.mob.VexEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FactionsMod implements ModInitializer {
    public static final String MOD_ID = "factions";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Шанс, что житель получит оружие TaCZ при появлении (если TaCZ установлен). */
    public static final float VILLAGER_ARM_CHANCE = 0.3f;
    /** Сколько солдат может быть у одного игрока. */
    public static final int MAX_SOLDIERS_PER_PLAYER = 15;
    private static final String ROLLED_TAG = "factions_arm_rolled";

    public static EntityType<SoldierEntity> SOLDIER;
    public static Item RECRUIT_ORDER;

    /** Сторона игрока: хранится в сохранении и переживает смерть. */
    public static final AttachmentType<Integer> FACTION = AttachmentRegistry.<Integer>builder()
            .persistent(Codec.INT)
            .copyOnDeath()
            .initializer(() -> 0)
            .buildAndRegister(Identifier.of(MOD_ID, "faction"));

    // Сервер -> клиент: открыть меню выбора
    public record OpenMenuPayload() implements CustomPayload {
        public static final Id<OpenMenuPayload> ID = new Id<>(Identifier.of(MOD_ID, "open_menu"));
        public static final PacketCodec<ByteBuf, OpenMenuPayload> CODEC = PacketCodec.unit(new OpenMenuPayload());

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    // Клиент -> сервер: игрок выбрал сторону
    public record ChoosePayload(int faction) implements CustomPayload {
        public static final Id<ChoosePayload> ID = new Id<>(Identifier.of(MOD_ID, "choose"));
        public static final PacketCodec<ByteBuf, ChoosePayload> CODEC =
                PacketCodecs.VAR_INT.xmap(ChoosePayload::new, ChoosePayload::faction);

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    // Клиент -> сервер: команда отряду (набор, следовать/стоять, собрать, атаковать цель)
    public record SquadCommandPayload(int action, int squad, int soldierClass) implements CustomPayload {
        public static final Id<SquadCommandPayload> ID = new Id<>(Identifier.of(MOD_ID, "squad_command"));
        public static final PacketCodec<ByteBuf, SquadCommandPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, SquadCommandPayload::action,
                PacketCodecs.VAR_INT, SquadCommandPayload::squad,
                PacketCodecs.VAR_INT, SquadCommandPayload::soldierClass,
                SquadCommandPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---------- стороны ----------

    public static Faction getFaction(PlayerEntity p) {
        return Faction.byId(p.getAttachedOrElse(FACTION, 0));
    }

    public static void setFaction(PlayerEntity p, Faction f) {
        p.setAttached(FACTION, f.ordinal());
    }

    /** Разбойники, поборники, разорители, чародеи, ведьмы, иллюзоры, вексы. */
    public static boolean isEvilMob(Entity e) {
        return e instanceof RaiderEntity || e instanceof VexEntity;
    }

    /** Жители и железные големы. */
    public static boolean isGoodMob(Entity e) {
        return e instanceof VillagerEntity || e instanceof IronGolemEntity;
    }

    /** Игрок зла или солдат зла. */
    public static boolean isEvilTarget(LivingEntity e) {
        if (e instanceof PlayerEntity p) return !p.isSpectator() && getFaction(p) == Faction.EVIL;
        return e instanceof SoldierEntity s && s.getFaction() == Faction.EVIL;
    }

    /** Игрок добра или солдат добра. */
    public static boolean isGoodTarget(LivingEntity e) {
        if (e instanceof PlayerEntity p) return !p.isSpectator() && getFaction(p) == Faction.GOOD;
        return e instanceof SoldierEntity s && s.getFaction() == Faction.GOOD;
    }

    /** Враги стороны добра: все монстры, игроки и солдаты зла. */
    public static boolean isGoodSideEnemy(LivingEntity e) {
        return e instanceof Monster || isEvilTarget(e);
    }

    /** Враги стороны зла: жители, големы, игроки и солдаты добра. */
    public static boolean isEvilSideEnemy(LivingEntity e) {
        return isGoodMob(e) || isGoodTarget(e);
    }

    // ---------- инициализация ----------

    @Override
    public void onInitialize() {
        SOLDIER = Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "soldier"),
                EntityType.Builder.create(SoldierEntity::new, SpawnGroup.CREATURE)
                        .dimensions(0.6f, 1.95f).maxTrackingRange(10).build("soldier"));
        FabricDefaultAttributeRegistry.register(SOLDIER, SoldierEntity.createSoldierAttributes());

        RECRUIT_ORDER = Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "recruit_order"),
                new RecruitOrderItem(new Item.Settings().maxCount(16)));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(RECRUIT_ORDER));

        PayloadTypeRegistry.playS2C().register(OpenMenuPayload.ID, OpenMenuPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ChoosePayload.ID, ChoosePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SquadCommandPayload.ID, SquadCommandPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SquadCommandPayload.ID,
                (payload, context) -> SquadCommands.handle(context.player(), payload.action(),
                        payload.squad(), payload.soldierClass()));

        ServerPlayNetworking.registerGlobalReceiver(ChoosePayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            Faction f = Faction.byId(payload.faction());
            if (getFaction(player) != Faction.NONE || f == Faction.NONE) return;
            setFaction(player, f);
            player.sendMessage(f == Faction.GOOD
                    ? Text.literal("Ты встал на сторону добра.").formatted(Formatting.GREEN)
                    : Text.literal("Ты встал на сторону зла.").formatted(Formatting.DARK_RED), false);
        });

        // Совместимость с TaCZ: часть жителей берёт оружие и воюет
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof VillagerEntity villager) || !TaczCompat.isAvailable()) return;
            ((MobEntityAccessor) villager).factions$getGoalSelector().add(2,
                    new GunGoal(villager, FactionsMod::isGoodSideEnemy, () -> true, 0.6));
            if (villager.getCommandTags().contains(ROLLED_TAG)) return;
            if (world.getRandom().nextFloat() < VILLAGER_ARM_CHANCE) {
                ItemStack gun = TaczCompat.createRandomGun(world.getRandom());
                if (gun.isEmpty()) return; // не удалось, попробуем при следующей загрузке
                villager.equipStack(EquipmentSlot.MAINHAND, gun);
                villager.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
            }
            villager.addCommandTag(ROLLED_TAG);
        });

        // Меню при входе, пока сторона не выбрана
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            if (getFaction(handler.getPlayer()) == Faction.NONE) {
                sender.sendPacket(new OpenMenuPayload());
            }
        });

        // /faction reset — сбросить сторону и открыть меню заново (для админов и тестов)
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) ->
                dispatcher.register(CommandManager.literal("faction")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("reset").executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            setFaction(p, Faction.NONE);
                            ServerPlayNetworking.send(p, new OpenMenuPayload());
                            return 1;
                        }))));
    }
}
