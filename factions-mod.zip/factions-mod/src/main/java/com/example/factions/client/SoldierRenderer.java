package com.example.factions.client;

import com.example.factions.Faction;
import com.example.factions.FactionsMod;
import com.example.factions.entity.SoldierEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

public class SoldierRenderer extends BipedEntityRenderer<SoldierEntity, PlayerEntityModel<SoldierEntity>> {
    private static final Identifier[][] TEXTURES = new Identifier[2][SoldierEntity.CLASS_COUNT];

    static {
        for (int c = 0; c < SoldierEntity.CLASS_COUNT; c++) {
            TEXTURES[0][c] = Identifier.of(FactionsMod.MOD_ID, "textures/entity/soldier_good_" + c + ".png");
            TEXTURES[1][c] = Identifier.of(FactionsMod.MOD_ID, "textures/entity/soldier_evil_" + c + ".png");
        }
    }

    public SoldierRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
        addFeature(new ArmorFeatureRenderer<>(this,
                new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER_INNER_ARMOR)),
                new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    @Override
    public Identifier getTexture(SoldierEntity entity) {
        int side = entity.getFaction() == Faction.EVIL ? 1 : 0;
        int cls = Math.max(0, Math.min(SoldierEntity.CLASS_COUNT - 1, entity.getSoldierClass()));
        return TEXTURES[side][cls];
    }
}
