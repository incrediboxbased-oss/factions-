package com.example.factions.client;

import com.example.factions.Faction;
import com.example.factions.FactionsMod;
import com.example.factions.compat.TaczCompat;
import com.example.factions.entity.SoldierEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

public class SoldierRenderer extends BipedEntityRenderer<SoldierEntity, PlayerEntityModel<SoldierEntity>> {
    private static final Identifier[][] TEXTURES = new Identifier[2][SoldierEntity.CLASS_GUARD + 1];

    static {
        for (int c = 0; c <= SoldierEntity.CLASS_GUARD; c++) {
            TEXTURES[0][c] = Identifier.of(FactionsMod.MOD_ID, "textures/entity/soldier_good_" + c + ".png");
            TEXTURES[1][c] = Identifier.of(FactionsMod.MOD_ID, "textures/entity/soldier_evil_" + c + ".png");
        }
    }

    public SoldierRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
        addFeature(new ArmorFeatureRenderer<>(this,
                new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER_INNER_ARMOR)),
                new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    private static BipedEntityModel.ArmPose poseFor(ItemStack stack) {
        if (TaczCompat.isGun(stack)) return BipedEntityModel.ArmPose.BOW_AND_ARROW; // обе руки на оружии
        return stack.isEmpty() ? BipedEntityModel.ArmPose.EMPTY : BipedEntityModel.ArmPose.ITEM;
    }

    @Override
    public void render(SoldierEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        PlayerEntityModel<SoldierEntity> model = getModel();
        ItemStack main = entity.getMainHandStack();
        model.rightArmPose = poseFor(main);
        model.leftArmPose = TaczCompat.isGun(main) ? poseFor(main) : poseFor(entity.getOffHandStack());
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    @Override
    public Identifier getTexture(SoldierEntity entity) {
        int side = entity.getFaction() == Faction.EVIL ? 1 : 0;
        int cls = Math.max(0, Math.min(SoldierEntity.CLASS_GUARD, entity.getSoldierClass()));
        return TEXTURES[side][cls];
    }
}
