package com.example.factions.client;

import com.example.factions.Faction;
import com.example.factions.compat.TaczCompat;
import com.example.factions.loadout.Loadout;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Меню снаряжения для новых бойцов. Предложения зависят от выбранной стороны. */
public class LoadoutScreen extends Screen {
    private ButtonWidget kindBtn, meleeBtn, gunBtn, armorBtn;
    private final List<String> guns = new ArrayList<>();

    public LoadoutScreen() {
        super(Text.translatable("screen.factions.loadout"));
    }

    private static void set(Loadout l) { ClientState.loadout = l; }

    @Override
    protected void init() {
        guns.clear();
        guns.add("");
        guns.addAll(TaczCompat.listGunIds());

        int x = this.width / 2 - 110;
        int y = this.height / 2 - 55;

        kindBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            Loadout l = ClientState.loadout;
            int k = (l.weaponKind() + 1) % 2;
            if (k == 1 && !TaczCompat.isAvailable()) k = 0;
            set(new Loadout(l.melee(), k, l.armor(), l.gunId()));
            refresh();
        }).dimensions(x, y, 220, 20).build());

        meleeBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            Loadout l = ClientState.loadout;
            set(new Loadout((l.melee() + 1) % Loadout.MELEE_OPTIONS, l.weaponKind(), l.armor(), l.gunId()));
            refresh();
        }).dimensions(x, y + 24, 220, 20).build());

        gunBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            Loadout l = ClientState.loadout;
            int next = (Math.max(0, guns.indexOf(l.gunId())) + 1) % guns.size();
            set(new Loadout(l.melee(), l.weaponKind(), l.armor(), guns.get(next)));
            refresh();
        }).dimensions(x, y + 48, 220, 20).build());

        armorBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            Loadout l = ClientState.loadout;
            set(new Loadout(l.melee(), l.weaponKind(), (l.armor() + 1) % Loadout.ARMOR_TIERS, l.gunId()));
            refresh();
        }).dimensions(x, y + 72, 220, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> close())
                .dimensions(x, y + 104, 220, 20).build());
        refresh();
    }

    private void refresh() {
        Loadout l = ClientState.loadout;
        Faction f = ClientState.faction();
        kindBtn.setMessage(Text.translatable("loadout.factions.kind", Text.translatable(
                l.weaponKind() == 1 ? "loadout.factions.kind_gun" : "loadout.factions.kind_melee")));
        meleeBtn.setMessage(Text.translatable("loadout.factions.melee",
                new ItemStack(Loadout.meleeItem(f, l.melee())).getName()));
        gunBtn.setMessage(Text.translatable("loadout.factions.gun",
                l.gunId().isEmpty() ? Text.translatable("loadout.factions.gun_random") : Text.literal(l.gunId())));
        gunBtn.active = TaczCompat.isAvailable();
        kindBtn.active = TaczCompat.isAvailable();
        armorBtn.setMessage(Text.translatable("loadout.factions.armor", Loadout.armorName(l.armor())));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 80, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("loadout.factions.hint").formatted(Formatting.GRAY),
                this.width / 2, this.height / 2 + 75, 0xFFFFFF);
    }
}
