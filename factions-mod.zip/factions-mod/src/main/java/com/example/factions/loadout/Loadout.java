package com.example.factions.loadout;

import com.example.factions.Faction;
import io.netty.buffer.ByteBuf;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.DyedColorComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.text.Text;

/**
 * Набор снаряжения для новых бойцов. Список оружия и цвет кожаной брони зависят от стороны:
 * добро — мечи, зло — топоры.
 */
public record Loadout(int melee, int weaponKind, int armor, String gunId) {
    public static final int MELEE_OPTIONS = 4;
    public static final int ARMOR_TIERS = 5;

    public static final Loadout DEFAULT = new Loadout(0, 0, 1, "");

    public static final PacketCodec<ByteBuf, Loadout> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, Loadout::melee,
            PacketCodecs.VAR_INT, Loadout::weaponKind,
            PacketCodecs.VAR_INT, Loadout::armor,
            PacketCodecs.string(64), Loadout::gunId,
            Loadout::new);

    private static final Item[] GOOD_MELEE = {Items.STONE_SWORD, Items.IRON_SWORD, Items.DIAMOND_SWORD, Items.IRON_AXE};
    private static final Item[] EVIL_MELEE = {Items.STONE_AXE, Items.IRON_AXE, Items.DIAMOND_AXE, Items.IRON_SWORD};

    private static final Item[][] ARMOR = {
            {},
            {Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS},
            {Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS},
            {Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS},
            {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS}
    };
    private static final EquipmentSlot[] SLOTS =
            {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    public Loadout sanitize() {
        return new Loadout(clamp(melee, 0, MELEE_OPTIONS - 1), clamp(weaponKind, 0, 1),
                clamp(armor, 0, ARMOR_TIERS - 1), gunId == null || gunId.length() > 64 ? "" : gunId);
    }

    public static Item meleeItem(Faction faction, int index) {
        Item[] list = faction == Faction.EVIL ? EVIL_MELEE : GOOD_MELEE;
        return list[clamp(index, 0, list.length - 1)];
    }

    public static Text armorName(int tier) {
        return Text.translatable("loadout.factions.armor_" + clamp(tier, 0, ARMOR_TIERS - 1));
    }

    /** Надевает броню нужного уровня; кожаная красится в цвет стороны. */
    public static void equipArmor(LivingEntity entity, Faction faction, int tier) {
        Item[] pieces = ARMOR[clamp(tier, 0, ARMOR_TIERS - 1)];
        for (int i = 0; i < pieces.length; i++) {
            ItemStack stack = new ItemStack(pieces[i]);
            if (tier == 1) {
                int color = faction == Faction.EVIL ? 0x7A1E1E : 0x2D55A5;
                stack.set(DataComponentTypes.DYED_COLOR, new DyedColorComponent(color, false));
            }
            entity.equipStack(SLOTS[i], stack);
            if (entity instanceof net.minecraft.entity.mob.MobEntity mob) {
                mob.setEquipmentDropChance(SLOTS[i], 1.0f);
            }
        }
    }
}
