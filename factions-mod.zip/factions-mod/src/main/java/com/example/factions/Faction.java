package com.example.factions;

public enum Faction {
    NONE, GOOD, EVIL;

    public static Faction byId(int id) {
        Faction[] v = values();
        return id >= 0 && id < v.length ? v[id] : NONE;
    }
}
