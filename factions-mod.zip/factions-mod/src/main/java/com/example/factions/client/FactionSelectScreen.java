package com.example.factions.client;

import com.example.factions.Faction;
import com.example.factions.FactionsMod;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class FactionSelectScreen extends Screen {
    public FactionSelectScreen() {
        super(Text.literal("Выбери свою сторону"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Добро").formatted(Formatting.GREEN), b -> choose(Faction.GOOD))
                .dimensions(cx - 105, cy - 20, 210, 20).build());
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Зло").formatted(Formatting.DARK_RED), b -> choose(Faction.EVIL))
                .dimensions(cx - 105, cy + 30, 210, 20).build());
    }

    private void choose(Faction f) {
        ClientPlayNetworking.send(new FactionsMod.ChoosePayload(f.ordinal()));
        close();
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // нельзя закрыть без выбора
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int cy = this.height / 2;
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, cy - 50, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Жители и големы тебе друзья, разбойники — враги").formatted(Formatting.GRAY),
                cx, cy + 1, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Разбойники тебя не тронут, а жители и големы — враги").formatted(Formatting.GRAY),
                cx, cy + 51, 0xFFFFFF);
    }
}
