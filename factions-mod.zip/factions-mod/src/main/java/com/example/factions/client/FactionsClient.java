package com.example.factions.client;

import com.example.factions.FactionsMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class FactionsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(FactionsMod.OpenMenuPayload.ID,
                (payload, context) -> context.client().setScreen(new FactionSelectScreen()));
        ClientPlayNetworking.registerGlobalReceiver(FactionsMod.FactionSyncPayload.ID,
                (payload, context) -> ClientState.faction = payload.faction());
        EntityRendererRegistry.register(FactionsMod.SOLDIER, SoldierRenderer::new);
        SquadKeys.register();
    }
}
