package com.example.factions.mixin.soft;

import com.example.factions.FactionsMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Пули TaCZ от мобов наносят меньше урона, чтобы бой не заканчивался за секунду. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true)
    private float factions$softenMobBullets(float amount, DamageSource source) {
        Entity attacker = source.getAttacker();
        Entity direct = source.getSource();
        if (attacker instanceof MobEntity && direct != null
                && direct.getClass().getName().startsWith("com.tacz.guns")) {
            return amount * FactionsMod.MOB_GUN_DAMAGE_MULTIPLIER;
        }
        return amount;
    }
}
