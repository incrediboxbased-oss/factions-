package com.example.factions.client;

import com.example.factions.Faction;
import com.example.factions.loadout.Loadout;

/** Что клиент знает о себе: сторона (приходит с сервера) и выбранное снаряжение для набора. */
public final class ClientState {
    public static int faction = 0;
    public static Loadout loadout = Loadout.DEFAULT;

    private ClientState() {}

    public static Faction faction() { return Faction.byId(faction); }
}
