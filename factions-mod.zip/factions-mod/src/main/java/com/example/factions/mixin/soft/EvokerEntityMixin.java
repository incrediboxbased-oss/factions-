package com.example.factions.mixin.soft;

import com.example.factions.mixin.MobEntityAccessor;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.mob.EvokerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Заклинатель не убегает от игроков. */
@Mixin(EvokerEntity.class)
public abstract class EvokerEntityMixin {
    @Inject(method = "initGoals", at = @At("TAIL"))
    private void factions$noFear(CallbackInfo ci) {
        ((MobEntityAccessor) (Object) this).factions$getGoalSelector().getGoals()
                .removeIf(g -> g.getGoal() instanceof FleeEntityGoal<?>);
    }
}
