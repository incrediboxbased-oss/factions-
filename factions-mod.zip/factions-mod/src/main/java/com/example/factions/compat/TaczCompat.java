package com.example.factions.compat;

import com.example.factions.FactionsMod;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Мост к Timeless and Classics Zero (TaCZ Refabricated) через рефлексию:
 * мод собирается и работает без TaCZ, а с ним — включает оружие у жителей, бойцов и рейдеров.
 */
public final class TaczCompat {
    private static final int REFILL_AMMO = 30;

    private static boolean initDone;
    private static boolean ready;
    private static int shootLogBudget = 12;
    private static Class<?> gunInterface, operatorClass, builderClass, apiClass;
    private static Method fromEntity;

    private TaczCompat() {}

    public static boolean isAvailable() {
        if (!initDone) {
            initDone = true;
            try {
                gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
                operatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                builderClass = Class.forName("com.tacz.guns.api.item.builder.GunItemBuilder");
                apiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                fromEntity = operatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                ready = true;
                FactionsMod.LOGGER.info("TaCZ найден: оружие включено.");
            } catch (ClassNotFoundException e) {
                // TaCZ не установлен — это нормально
            } catch (Throwable t) {
                disable(t);
            }
        }
        return ready;
    }

    public static boolean isGun(ItemStack stack) {
        return isAvailable() && !stack.isEmpty() && gunInterface.isInstance(stack.getItem());
    }

    /** Идентификаторы всех установленных пушек (для меню снаряжения). */
    public static List<String> listGunIds() {
        List<String> ids = new ArrayList<>();
        if (!isAvailable()) return ids;
        for (String method : new String[]{"getAllClientGunIndex", "getAllCommonGunIndex"}) {
            try {
                Object res = apiClass.getMethod(method).invoke(null);
                if (res instanceof Collection<?> c) {
                    for (Object o : c) {
                        if (o instanceof Map.Entry<?, ?> e) ids.add(String.valueOf(e.getKey()));
                    }
                }
            } catch (Throwable ignored) { }
            if (!ids.isEmpty()) break;
        }
        Collections.sort(ids);
        return ids;
    }

    public static ItemStack createRandomGun(Random random) {
        return createGun(random, "");
    }

    /** Пушка по id (например tacz:ak47) или случайная, если id пустой или не найден. */
    public static ItemStack createGun(Random random, String gunId) {
        if (!isAvailable()) return ItemStack.EMPTY;
        try {
            Collection<?> all = (Collection<?>) apiClass.getMethod("getAllCommonGunIndex").invoke(null);
            if (all.isEmpty()) return ItemStack.EMPTY;
            List<Object> list = new ArrayList<>(all);
            Map.Entry<?, ?> entry = null;
            if (gunId != null && !gunId.isEmpty()) {
                for (Object o : list) {
                    if (o instanceof Map.Entry<?, ?> e && String.valueOf(e.getKey()).equals(gunId)) {
                        entry = e;
                        break;
                    }
                }
            }
            if (entry == null) entry = (Map.Entry<?, ?>) list.get(random.nextInt(list.size()));

            Object gunData = call(entry.getValue(), "getGunData");
            Object fireMode = null;
            try {
                Object modes = call(gunData, "getFireModeSet");
                if (modes instanceof Collection<?> c && !c.isEmpty()) fireMode = c.iterator().next();
            } catch (Exception ignored) { }

            Object builder = builderClass.getMethod("create").invoke(null);
            call(builder, "setId", entry.getKey());
            if (fireMode != null) tryCall(builder, "setFireMode", fireMode);
            tryCall(builder, "setAmmoCount", REFILL_AMMO);
            tryCall(builder, "setBulletInBarrel", true);
            return (ItemStack) call(builder, "build");
        } catch (Throwable t) {
            disable(t);
            return ItemStack.EMPTY;
        }
    }

    public static void draw(LivingEntity e) {
        if (!ready) return;
        try {
            Supplier<ItemStack> hand = e::getMainHandStack;
            call(operator(e), "draw", hand);
        } catch (Throwable t) { disable(t); }
    }

    public static void aim(LivingEntity e, boolean aiming) {
        if (!ready) return;
        try { call(operator(e), "aim", aiming); } catch (Throwable t) { disable(t); }
    }

    public static void bolt(LivingEntity e) {
        if (!ready) return;
        try { tryCall(operator(e), "bolt"); } catch (Throwable ignored) { }
    }

    /** Возвращает имя результата TaCZ (SUCCESS, COOL_DOWN, NOT_DRAW, NO_AMMO...). */
    public static String shoot(LivingEntity e) {
        if (!ready) return "UNAVAILABLE";
        try {
            Supplier<Float> pitch = e::getPitch;
            Supplier<Float> yaw = e::getYaw;
            Object result = call(operator(e), "shoot", pitch, yaw);
            String name = result == null ? "NULL" : result.toString();
            if (!name.equals("SUCCESS") && !name.equals("COOL_DOWN") && shootLogBudget > 0) {
                shootLogBudget--;
                FactionsMod.LOGGER.info("TaCZ shoot -> {}", name);
            }
            return name;
        } catch (Throwable t) {
            disable(t);
            return "ERROR";
        }
    }

    public static int ammo(ItemStack gun) {
        if (!ready) return 0;
        try { return (Integer) call(gun.getItem(), "getCurrentAmmoCount", gun); }
        catch (Throwable t) { disable(t); return 0; }
    }

    /** «Перезарядка»: пополняет магазин, патроны из инвентаря не нужны. */
    public static void refill(ItemStack gun) {
        if (!ready) return;
        try {
            call(gun.getItem(), "setCurrentAmmoCount", gun, REFILL_AMMO);
            tryCall(gun.getItem(), "setBulletInBarrel", gun, true);
        } catch (Throwable t) { disable(t); }
    }

    private static Object operator(LivingEntity e) throws Exception {
        return fromEntity.invoke(null, e);
    }

    private static Object call(Object target, String name, Object... args) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == args.length) {
                return m.invoke(target, args);
            }
        }
        throw new NoSuchMethodException(target.getClass().getName() + "#" + name + "/" + args.length);
    }

    private static void tryCall(Object target, String name, Object... args) {
        try { call(target, name, args); } catch (Exception ignored) { }
    }

    private static void disable(Throwable t) {
        if (ready || !initDone) {
            FactionsMod.LOGGER.warn("API TaCZ не совпало с ожидаемым, интеграция отключена", t);
        }
        ready = false;
    }
}
