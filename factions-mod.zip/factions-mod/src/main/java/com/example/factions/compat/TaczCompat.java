package com.example.factions.compat;

import com.example.factions.FactionsMod;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Мост к Timeless and Classics Zero (TaCZ Refabricated) через рефлексию:
 * мод собирается и работает без TaCZ, а с ним — включает оружие у жителей.
 * Если API TaCZ окажется другим, модуль тихо отключится и напишет причину в лог.
 */
public final class TaczCompat {
    private static final int REFILL_AMMO = 30;

    private static boolean initDone;
    private static boolean ready;
    private static Class<?> gunInterface, operatorClass, builderClass, apiClass;
    private static Method fromEntity;

    private TaczCompat() {}

    public static boolean isAvailable() {
        if (!initDone) {
            initDone = true;
            try {
                gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
                operatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                builderClass = Class.forName("com.tacz.guns.api.item.builder.GunItemBuilder");
                apiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                fromEntity = operatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                ready = true;
                FactionsMod.LOGGER.info("TaCZ найден: жители смогут пользоваться оружием.");
            } catch (ClassNotFoundException e) {
                // TaCZ не установлен — это нормально
            } catch (Throwable t) {
                disable(t);
            }
        }
        return ready;
    }

    public static boolean isGun(ItemStack stack) {
        return isAvailable() && !stack.isEmpty() && gunInterface.isInstance(stack.getItem());
    }

    /** Случайное оружие из всех установленных (включая оружейные паки). */
    public static ItemStack createRandomGun(Random random) {
        if (!isAvailable()) return ItemStack.EMPTY;
        try {
            Collection<?> all = (Collection<?>) apiClass.getMethod("getAllCommonGunIndex").invoke(null);
            if (all.isEmpty()) return ItemStack.EMPTY;
            List<Object> list = new ArrayList<>(all);
            Map.Entry<?, ?> entry = (Map.Entry<?, ?>) list.get(random.nextInt(list.size()));

            Object gunData = call(entry.getValue(), "getGunData");
            Object fireMode = null;
            try {
                Object modes = call(gunData, "getFireModeSet");
                if (modes instanceof Collection<?> c && !c.isEmpty()) fireMode = c.iterator().next();
            } catch (Exception ignored) { }

            Object builder = builderClass.getMethod("create").invoke(null);
            call(builder, "setId", entry.getKey());
            if (fireMode != null) tryCall(builder, "setFireMode", fireMode);
            tryCall(builder, "setAmmoCount", REFILL_AMMO);
            tryCall(builder, "setBulletInBarrel", true);
            return (ItemStack) call(builder, "build");
        } catch (Throwable t) {
            disable(t);
            return ItemStack.EMPTY;
        }
    }

    public static void draw(LivingEntity e) {
        if (!ready) return;
        try {
            Supplier<ItemStack> hand = e::getMainHandStack;
            call(operator(e), "draw", hand);
        } catch (Throwable t) { disable(t); }
    }

    public static void aim(LivingEntity e, boolean aiming) {
        if (!ready) return;
        try { call(operator(e), "aim", aiming); } catch (Throwable t) { disable(t); }
    }

    public static void shoot(LivingEntity e) {
        if (!ready) return;
        try {
            Supplier<Float> pitch = e::getPitch;
            Supplier<Float> yaw = e::getYaw;
            call(operator(e), "shoot", pitch, yaw);
        } catch (Throwable t) { disable(t); }
    }

    public static int ammo(ItemStack gun) {
        if (!ready) return 0;
        try { return (Integer) call(gun.getItem(), "getCurrentAmmoCount", gun); }
        catch (Throwable t) { disable(t); return 0; }
    }

    /** «Перезарядка»: просто пополняет магазин, патроны из инвентаря не нужны. */
    public static void refill(ItemStack gun) {
        if (!ready) return;
        try {
            call(gun.getItem(), "setCurrentAmmoCount", gun, REFILL_AMMO);
            tryCall(gun.getItem(), "setBulletInBarrel", gun, true);
        } catch (Throwable t) { disable(t); }
    }

    private static Object operator(LivingEntity e) throws Exception {
        return fromEntity.invoke(null, e);
    }

    private static Object call(Object target, String name, Object... args) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == args.length) {
                return m.invoke(target, args);
            }
        }
        throw new NoSuchMethodException(target.getClass().getName() + "#" + name + "/" + args.length);
    }

    private static void tryCall(Object target, String name, Object... args) {
        try { call(target, name, args); } catch (Exception ignored) { }
    }

    private static void disable(Throwable t) {
        if (ready || !initDone) {
            FactionsMod.LOGGER.warn("API TaCZ не совпало с ожидаемым, интеграция отключена", t);
        }
        ready = false;
    }
}
