package com.example.factions.compat;

import com.example.factions.FactionsMod;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Мост к Timeless and Classics Zero (TaCZ Refabricated) через рефлексию.
 * Выдаются только пистолеты, пистолеты-пулемёты и винтовки: никаких пулемётов,
 * миниганов, гранатомётов, дробовиков и снайперок.
 */
public final class TaczCompat {
    private static final int REFILL_AMMO = 30;
    private static final Set<String> ALLOWED_TYPES = Set.of("pistol", "smg", "rifle");
    private static final String[] DENY_IDS = {"minigun", "m134", "m249", "rpk", "pkm", "rpg", "m320",
            "launcher", "grenade", "javelin", "fim92", "m60", "mg42", "machinegun"};

    private static boolean initDone;
    private static boolean ready;
    private static int shootLogBudget = 12;
    private static Class<?> gunInterface, operatorClass, builderClass, apiClass;
    private static Method fromEntity;

    private TaczCompat() {}

    public static boolean isAvailable() {
        if (!initDone) {
            initDone = true;
            try {
                gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
                operatorClass = Class.forName("com.tacz.guns.api.entity.IGunOperator");
                builderClass = Class.forName("com.tacz.guns.api.item.builder.GunItemBuilder");
                apiClass = Class.forName("com.tacz.guns.api.TimelessAPI");
                fromEntity = operatorClass.getMethod("fromLivingEntity", LivingEntity.class);
                ready = true;
                FactionsMod.LOGGER.info("TaCZ найден: оружие включено.");
            } catch (ClassNotFoundException e) {
                // TaCZ не установлен — это нормально
            } catch (Throwable t) {
                disable(t);
            }
        }
        return ready;
    }

    public static boolean isGun(ItemStack stack) {
        return isAvailable() && !stack.isEmpty() && gunInterface.isInstance(stack.getItem());
    }

    // ---------- каталог оружия ----------

    private static List<Map.Entry<?, ?>> entriesFrom(String method) {
        List<Map.Entry<?, ?>> out = new ArrayList<>();
        try {
            Object res = apiClass.getMethod(method).invoke(null);
            if (res instanceof Collection<?> c) {
                for (Object o : c) {
                    if (o instanceof Map.Entry<?, ?> e) out.add(e);
                }
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private static String typeOf(Map.Entry<?, ?> e) {
        try {
            Object t = call(e.getValue(), "getType");
            return t == null ? null : t.toString().toLowerCase(Locale.ROOT);
        } catch (Exception ex) {
            return null;
        }
    }

    private static boolean denied(Map.Entry<?, ?> e) {
        String id = String.valueOf(e.getKey()).toLowerCase(Locale.ROOT);
        for (String bad : DENY_IDS) {
            if (id.contains(bad)) return true;
        }
        return false;
    }

    private static List<Map.Entry<?, ?>> filter(List<Map.Entry<?, ?>> all, Set<String> types) {
        List<Map.Entry<?, ?>> out = new ArrayList<>();
        for (Map.Entry<?, ?> e : all) {
            if (denied(e)) continue;
            String type = typeOf(e);
            boolean ok = type != null ? types.contains(type) : types.contains("rifle");
            if (ok) out.add(e);
        }
        return out;
    }

    private static Set<String> typesOf(String... types) {
        Set<String> set = new java.util.HashSet<>();
        for (String t : types) set.add(t.toLowerCase(Locale.ROOT));
        return set;
    }

    /** Идентификаторы разрешённых пушек (для меню снаряжения). */
    public static List<String> listGunIds() {
        List<String> ids = new ArrayList<>();
        if (!isAvailable()) return ids;
        for (String method : new String[]{"getAllClientGunIndex", "getAllCommonGunIndex"}) {
            for (Map.Entry<?, ?> e : filter(entriesFrom(method), ALLOWED_TYPES)) ids.add(String.valueOf(e.getKey()));
            if (!ids.isEmpty()) break;
        }
        Collections.sort(ids);
        return ids;
    }

    public static ItemStack createRandomGun(Random random) {
        return createGun(random, "");
    }

    /** Пушка по id (например tacz:glock_17) или случайная разрешённая, если id пустой или запрещён. */
    public static ItemStack createGun(Random random, String gunId) {
        if (!isAvailable()) return ItemStack.EMPTY;
        List<Map.Entry<?, ?>> pool = filter(entriesFrom("getAllCommonGunIndex"), ALLOWED_TYPES);
        if (pool.isEmpty()) return ItemStack.EMPTY;
        Map.Entry<?, ?> entry = null;
        if (gunId != null && !gunId.isEmpty()) {
            for (Map.Entry<?, ?> e : pool) {
                if (String.valueOf(e.getKey()).equals(gunId)) { entry = e; break; }
            }
        }
        if (entry == null) entry = pool.get(random.nextInt(pool.size()));
        return buildGun(entry);
    }

    /** Случайная пушка заданных типов: "pistol", "smg", "rifle". Для торговли. */
    public static ItemStack createGunOfTypes(Random random, String... types) {
        if (!isAvailable()) return ItemStack.EMPTY;
        List<Map.Entry<?, ?>> pool = filter(entriesFrom("getAllCommonGunIndex"), typesOf(types));
        if (pool.isEmpty()) return ItemStack.EMPTY;
        return buildGun(pool.get(random.nextInt(pool.size())));
    }

    /** Патроны к случайной пушке заданных типов. Для торговли. */
    public static ItemStack createAmmoOfTypes(Random random, int count, String... types) {
        if (!isAvailable()) return ItemStack.EMPTY;
        List<Map.Entry<?, ?>> pool = filter(entriesFrom("getAllCommonGunIndex"), typesOf(types));
        if (pool.isEmpty()) return ItemStack.EMPTY;
        try {
            Map.Entry<?, ?> entry = pool.get(random.nextInt(pool.size()));
            Object ammoId = call(call(entry.getValue(), "getGunData"), "getAmmoId");
            Class<?> ammoBuilder = Class.forName("com.tacz.guns.api.item.builder.AmmoItemBuilder");
            Object b = ammoBuilder.getMethod("create").invoke(null);
            call(b, "setId", ammoId);
            call(b, "setCount", count);
            return (ItemStack) call(b, "build");
        } catch (Throwable t) {
            FactionsMod.LOGGER.info("Не удалось создать патроны TaCZ: {}", t.toString());
            return ItemStack.EMPTY;
        }
    }

    private static ItemStack buildGun(Map.Entry<?, ?> entry) {
        try {
            Object gunData = call(entry.getValue(), "getGunData");
            Object fireMode = null;
            try {
                Object modes = call(gunData, "getFireModeSet");
                if (modes instanceof Collection<?> c && !c.isEmpty()) fireMode = c.iterator().next();
            } catch (Exception ignored) { }

            Object builder = builderClass.getMethod("create").invoke(null);
            call(builder, "setId", entry.getKey());
            if (fireMode != null) tryCall(builder, "setFireMode", fireMode);
            tryCall(builder, "setAmmoCount", REFILL_AMMO);
            tryCall(builder, "setBulletInBarrel", true);
            return (ItemStack) call(builder, "build");
        } catch (Throwable t) {
            disable(t);
            return ItemStack.EMPTY;
        }
    }

    // ---------- действия оператора оружия ----------

    public static void draw(LivingEntity e) {
        if (!ready) return;
        try {
            Supplier<ItemStack> hand = e::getMainHandStack;
            call(operator(e), "draw", hand);
        } catch (Throwable t) { disable(t); }
    }

    public static void aim(LivingEntity e, boolean aiming) {
        if (!ready) return;
        try { call(operator(e), "aim", aiming); } catch (Throwable t) { disable(t); }
    }

    public static void bolt(LivingEntity e) {
        if (!ready) return;
        try { tryCall(operator(e), "bolt"); } catch (Throwable ignored) { }
    }

    /** Возвращает имя результата TaCZ (SUCCESS, COOL_DOWN, NOT_DRAW, NO_AMMO...). */
    public static String shoot(LivingEntity e) {
        if (!ready) return "UNAVAILABLE";
        try {
            Supplier<Float> pitch = e::getPitch;
            Supplier<Float> yaw = e::getYaw;
            Object result = call(operator(e), "shoot", pitch, yaw);
            String name = result == null ? "NULL" : result.toString();
            if (!name.equals("SUCCESS") && !name.equals("COOL_DOWN") && shootLogBudget > 0) {
                shootLogBudget--;
                FactionsMod.LOGGER.info("TaCZ shoot -> {}", name);
            }
            return name;
        } catch (Throwable t) {
            disable(t);
            return "ERROR";
        }
    }

    public static int ammo(ItemStack gun) {
        if (!ready) return 0;
        try { return (Integer) call(gun.getItem(), "getCurrentAmmoCount", gun); }
        catch (Throwable t) { disable(t); return 0; }
    }

    /** «Перезарядка» для бойцов: пополняет магазин, патроны из инвентаря не нужны. */
    public static void refill(ItemStack gun) {
        if (!ready) return;
        try {
            call(gun.getItem(), "setCurrentAmmoCount", gun, REFILL_AMMO);
            tryCall(gun.getItem(), "setBulletInBarrel", gun, true);
        } catch (Throwable t) { disable(t); }
    }

    private static Object operator(LivingEntity e) throws Exception {
        return fromEntity.invoke(null, e);
    }

    private static Object call(Object target, String name, Object... args) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == args.length) {
                return m.invoke(target, args);
            }
        }
        throw new NoSuchMethodException(target.getClass().getName() + "#" + name + "/" + args.length);
    }

    private static void tryCall(Object target, String name, Object... args) {
        try { call(target, name, args); } catch (Exception ignored) { }
    }

    private static void disable(Throwable t) {
        if (ready || !initDone) {
            FactionsMod.LOGGER.warn("API TaCZ не совпало с ожидаемым, интеграция отключена", t);
        }
        ready = false;
    }
}
