package com.example.factions.mixin;

import com.example.factions.FactionsMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Мобы зла не выбирают целью игроков и бойцов зла.
 * Обычные монстры (зомби, скелеты, пауки...) дружелюбны: не трогают игроков, бойцов, жителей и големов.
 */
@Mixin(MobEntity.class)
public abstract class MobEntityMixin {
    @Inject(method = "setTarget", at = @At("HEAD"), cancellable = true)
    private void factions$relations(LivingEntity target, CallbackInfo ci) {
        if (target == null) return;
        Entity self = (Entity) (Object) this;
        if (FactionsMod.isEvilMob(self) && FactionsMod.isEvilTarget(target)) {
            ci.cancel();
            return;
        }
        if (FactionsMod.FRIENDLY_MONSTERS) {
            if (FactionsMod.isNeutralMonster(self) && FactionsMod.isSideMember(target)) {
                ci.cancel();
            } else if (self instanceof IronGolemEntity && FactionsMod.isNeutralMonster(target)) {
                ci.cancel();
            }
        }
    }
}
