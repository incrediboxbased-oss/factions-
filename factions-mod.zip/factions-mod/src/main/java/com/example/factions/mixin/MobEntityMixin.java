package com.example.factions.mixin;

import com.example.factions.FactionsMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Мобы зла не выбирают целью игроков и солдат зла. */
@Mixin(MobEntity.class)
public abstract class MobEntityMixin {
    @Inject(method = "setTarget", at = @At("HEAD"), cancellable = true)
    private void factions$spareEvilSide(LivingEntity target, CallbackInfo ci) {
        if (target != null && FactionsMod.isEvilMob((Entity) (Object) this) && FactionsMod.isEvilTarget(target)) {
            ci.cancel();
        }
    }
}
