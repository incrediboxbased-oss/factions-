package com.example.factions.item;

import com.example.factions.Faction;
import com.example.factions.FactionsMod;
import com.example.factions.entity.SoldierEntity;
import com.example.factions.loadout.Loadout;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Приказ о наборе: призывает одного солдата твоей стороны (а клавиша G набирает целый отряд). */
public class RecruitOrderItem extends Item {
    public RecruitOrderItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!(world instanceof ServerWorld sw)) return TypedActionResult.success(stack);

        Faction faction = FactionsMod.getFaction(player);
        if (faction == Faction.NONE) {
            player.sendMessage(Text.translatable("message.factions.no_faction"), true);
            return TypedActionResult.fail(stack);
        }
        if (SoldierEntity.ownedSoldiers(sw, player.getUuid()).size() >= FactionsMod.MAX_SOLDIERS_PER_PLAYER) {
            player.sendMessage(Text.translatable("message.factions.limit", FactionsMod.MAX_SOLDIERS_PER_PLAYER), true);
            return TypedActionResult.fail(stack);
        }
        Vec3d look = player.getRotationVec(1.0f);
        SoldierEntity soldier = SoldierEntity.spawn(sw, player, faction,
                player.getX() + look.x * 1.5, player.getZ() + look.z * 1.5,
                SoldierEntity.CLASS_MILITIA, 0, Loadout.DEFAULT);
        if (soldier == null) return TypedActionResult.fail(stack);

        stack.decrementUnlessCreative(1, player);
        return TypedActionResult.success(stack);
    }
}
