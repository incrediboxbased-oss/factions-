package com.example.factions.squad;

import com.example.factions.Faction;
import com.example.factions.FactionsMod;
import com.example.factions.entity.SoldierEntity;
import com.example.factions.loadout.Loadout;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

/** Команды отряду. Вызываются по клавишам с клиента. */
public final class SquadCommands {
    public static final int RECRUIT_SQUAD = 0;
    public static final int TOGGLE = 1;
    public static final int GATHER = 2;
    public static final int FOCUS = 3;
    public static final int RECRUIT_ONE = 4;

    /** Максимум бойцов в одном отряде. */
    public static final int SQUAD_SIZE = 5;
    private static final double FOCUS_RANGE = 48.0;

    private SquadCommands() {}

    public static void handle(ServerPlayerEntity player, int action, int squad, int soldierClass, Loadout loadout) {
        if (FactionsMod.getFaction(player) == Faction.NONE) {
            msg(player, Text.translatable("message.factions.no_faction"));
            return;
        }
        if (squad < 0 || squad >= SoldierEntity.SQUAD_COUNT) return;
        if (soldierClass < 0 || soldierClass >= SoldierEntity.CLASS_COUNT) return;
        ServerWorld world = (ServerWorld) player.getWorld();
        switch (action) {
            case RECRUIT_SQUAD -> recruit(player, world, squad, soldierClass, SQUAD_SIZE, loadout);
            case RECRUIT_ONE -> recruit(player, world, squad, soldierClass, 1, loadout);
            case TOGGLE -> toggle(player, world, squad);
            case GATHER -> gather(player, world, squad);
            case FOCUS -> focus(player, world, squad);
            default -> { }
        }
    }

    private static List<SoldierEntity> squadOf(ServerWorld world, ServerPlayerEntity player, int squad) {
        List<SoldierEntity> list = SoldierEntity.ownedSoldiers(world, player.getUuid());
        list.removeIf(s -> s.getSquad() != squad);
        list.sort(Comparator.comparing(Entity::getUuid));
        return list;
    }

    private static void recruit(ServerPlayerEntity player, ServerWorld world, int squad, int cls, int amount,
                                Loadout loadout) {
        int owned = SoldierEntity.ownedSoldiers(world, player.getUuid()).size();
        int inSquad = squadOf(world, player, squad).size();
        if (owned >= FactionsMod.MAX_SOLDIERS_PER_PLAYER) {
            msg(player, Text.translatable("message.factions.limit", FactionsMod.MAX_SOLDIERS_PER_PLAYER));
            return;
        }
        int want = Math.min(amount, Math.min(SQUAD_SIZE - inSquad, FactionsMod.MAX_SOLDIERS_PER_PLAYER - owned));
        if (want <= 0) {
            msg(player, Text.translatable("message.factions.squad_full", squad + 1));
            return;
        }
        Faction faction = FactionsMod.getFaction(player);
        int spawned = 0;
        for (int i = 0; i < want; i++) {
            if (!player.isCreative() && !takeOrder(player)) break;
            double angle = (inSquad + i) * (2 * Math.PI / SQUAD_SIZE);
            if (SoldierEntity.spawn(world, player, faction,
                    player.getX() + Math.cos(angle) * 2.5, player.getZ() + Math.sin(angle) * 2.5,
                    cls, squad, loadout) != null) {
                spawned++;
            }
        }
        msg(player, spawned == 0
                ? Text.translatable("message.factions.squad_no_orders")
                : Text.translatable("message.factions.squad_recruited", spawned, squad + 1));
    }

    private static boolean takeOrder(PlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(FactionsMod.RECRUIT_ORDER)) {
                s.decrement(1);
                return true;
            }
        }
        return false;
    }

    private static void toggle(ServerPlayerEntity player, ServerWorld world, int squad) {
        List<SoldierEntity> members = squadOf(world, player, squad);
        if (members.isEmpty()) { msg(player, Text.translatable("message.factions.squad_none", squad + 1)); return; }
        boolean anyFollowing = members.stream().anyMatch(s -> s.getOrder() == SoldierEntity.ORDER_FOLLOW);
        int next = anyFollowing ? SoldierEntity.ORDER_HOLD : SoldierEntity.ORDER_FOLLOW;
        members.forEach(s -> s.setOrder(next));
        msg(player, Text.translatable(next == SoldierEntity.ORDER_FOLLOW
                ? "message.factions.squad_follow" : "message.factions.squad_hold", squad + 1, members.size()));
    }

    private static void gather(ServerPlayerEntity player, ServerWorld world, int squad) {
        List<SoldierEntity> members = squadOf(world, player, squad);
        if (members.isEmpty()) { msg(player, Text.translatable("message.factions.squad_none", squad + 1)); return; }
        for (int i = 0; i < members.size(); i++) {
            SoldierEntity s = members.get(i);
            s.setOrder(SoldierEntity.ORDER_FOLLOW);
            if (s.squaredDistanceTo(player) > 100.0) {
                Vec3d p = SoldierEntity.formationPos(player, i, members.size(), squad);
                s.refreshPositionAndAngles(p.x, p.y, p.z, s.getYaw(), s.getPitch());
                s.getNavigation().stop();
            }
        }
        msg(player, Text.translatable("message.factions.squad_gather", squad + 1, members.size()));
    }

    private static void focus(ServerPlayerEntity player, ServerWorld world, int squad) {
        List<SoldierEntity> members = squadOf(world, player, squad);
        if (members.isEmpty()) { msg(player, Text.translatable("message.factions.squad_none", squad + 1)); return; }

        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d end = eye.add(look.multiply(FOCUS_RANGE));
        Box box = player.getBoundingBox().stretch(look.multiply(FOCUS_RANGE)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(player, eye, end, box,
                e -> e instanceof LivingEntity le && le.isAlive() && !e.isSpectator() && !(e instanceof SoldierEntity),
                FOCUS_RANGE * FOCUS_RANGE);

        if (hit == null || !(hit.getEntity() instanceof LivingEntity target)) {
            members.forEach(s -> s.setTarget(null));
            msg(player, Text.translatable("message.factions.squad_focus_clear", squad + 1));
            return;
        }
        int count = 0;
        for (SoldierEntity s : members) {
            if (s.getSoldierClass() != SoldierEntity.CLASS_MEDIC && !s.isAlly(target)) {
                s.setTarget(target);
                count++;
            }
        }
        msg(player, count == 0
                ? Text.translatable("message.factions.squad_focus_ally")
                : Text.translatable("message.factions.squad_focus", squad + 1, count));
    }

    private static void msg(ServerPlayerEntity player, Text text) {
        player.sendMessage(text, true);
    }
}
