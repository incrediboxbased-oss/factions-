package com.example.factions.client;

import com.example.factions.FactionsMod;
import com.example.factions.entity.SoldierEntity;
import com.example.factions.squad.SquadCommands;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Клавиши управления отрядами. Они появляются в Настройки → Управление → «Свет и Тьма»,
 * где игрок переназначает их как угодно.
 */
public final class SquadKeys {
    private static KeyBinding recruitSquad, recruitOne, toggle, gather, focus, nextSquad, nextClass;

    private static int activeSquad = 0;
    private static int activeClass = SoldierEntity.CLASS_MILITIA;

    private SquadKeys() {}

    private static KeyBinding make(String name, int defaultKey) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.factions." + name, InputUtil.Type.KEYSYM, defaultKey, "category.factions"));
    }

    public static void register() {
        recruitSquad = make("recruit_squad", GLFW.GLFW_KEY_G);
        recruitOne = make("recruit_one", GLFW.GLFW_KEY_J);
        toggle = make("toggle", GLFW.GLFW_KEY_V);
        gather = make("gather", GLFW.GLFW_KEY_B);
        focus = make("focus", GLFW.GLFW_KEY_X);
        nextSquad = make("next_squad", GLFW.GLFW_KEY_C);
        nextClass = make("next_class", GLFW.GLFW_KEY_H);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (nextSquad.wasPressed()) {
                activeSquad = (activeSquad + 1) % SoldierEntity.SQUAD_COUNT;
                info(client, Text.translatable("message.factions.active_squad", activeSquad + 1));
            }
            while (nextClass.wasPressed()) {
                activeClass = (activeClass + 1) % SoldierEntity.CLASS_COUNT;
                info(client, Text.translatable("message.factions.active_class",
                        Text.translatable("class.factions." + activeClass)));
            }
            while (recruitSquad.wasPressed()) send(SquadCommands.RECRUIT_SQUAD);
            while (recruitOne.wasPressed()) send(SquadCommands.RECRUIT_ONE);
            while (toggle.wasPressed()) send(SquadCommands.TOGGLE);
            while (gather.wasPressed()) send(SquadCommands.GATHER);
            while (focus.wasPressed()) send(SquadCommands.FOCUS);
        });
    }

    private static void info(MinecraftClient client, Text text) {
        if (client.player != null) client.player.sendMessage(text, true);
    }

    private static void send(int action) {
        ClientPlayNetworking.send(new FactionsMod.SquadCommandPayload(action, activeSquad, activeClass));
    }
}
