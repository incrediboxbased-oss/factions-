package com.example.factions.mixin;

import com.example.factions.FactionsMod;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Железные големы нападают на игроков и солдат зла. */
@Mixin(IronGolemEntity.class)
public abstract class IronGolemEntityMixin extends MobEntity {
    protected IronGolemEntityMixin(EntityType<? extends MobEntity> type, World world) {
        super(type, world);
    }

    @Inject(method = "initGoals", at = @At("TAIL"))
    private void factions$hateEvilSide(CallbackInfo ci) {
        this.targetSelector.add(3, new ActiveTargetGoal<>(this, LivingEntity.class, 10, true, false,
                FactionsMod::isEvilTarget));
    }
}
