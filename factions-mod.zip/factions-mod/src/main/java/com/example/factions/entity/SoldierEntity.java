package com.example.factions.entity;

import com.example.factions.Faction;
import com.example.factions.FactionsMod;
import com.example.factions.ai.GunGoal;
import com.example.factions.compat.TaczCompat;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

/** Боец стороны добра или зла. Классы: ополченец, стрелок, медик. Бойцы объединяются в отряды. */
public class SoldierEntity extends PathAwareEntity {
    public static final int ORDER_FOLLOW = 0;
    public static final int ORDER_HOLD = 1;

    public static final int CLASS_MILITIA = 0;
    public static final int CLASS_RIFLEMAN = 1;
    public static final int CLASS_MEDIC = 2;
    public static final int CLASS_COUNT = 3;

    public static final int SQUAD_COUNT = 3;

    private static final TrackedData<Integer> FACTION =
            DataTracker.registerData(SoldierEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ORDER =
            DataTracker.registerData(SoldierEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> SOLDIER_CLASS =
            DataTracker.registerData(SoldierEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> SQUAD =
            DataTracker.registerData(SoldierEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private UUID ownerUuid;

    public SoldierEntity(EntityType<? extends SoldierEntity> type, World world) {
        super(type, world);
        setCanPickUpLoot(false);
    }

    public static DefaultAttributeContainer.Builder createSoldierAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    // ---------- данные ----------

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(FACTION, Faction.GOOD.ordinal());
        builder.add(ORDER, ORDER_FOLLOW);
        builder.add(SOLDIER_CLASS, CLASS_MILITIA);
        builder.add(SQUAD, 0);
    }

    public Faction getFaction() { return Faction.byId(dataTracker.get(FACTION)); }
    public void setFaction(Faction f) { dataTracker.set(FACTION, f.ordinal()); }
    public int getOrder() { return dataTracker.get(ORDER); }
    public int getSoldierClass() { return dataTracker.get(SOLDIER_CLASS); }
    public int getSquad() { return dataTracker.get(SQUAD); }
    public void setSoldierClass(int c) { dataTracker.set(SOLDIER_CLASS, Math.max(0, Math.min(CLASS_COUNT - 1, c))); }
    public void setSquad(int s) { dataTracker.set(SQUAD, Math.max(0, Math.min(SQUAD_COUNT - 1, s))); }
    public void setOwnerUuid(UUID uuid) { this.ownerUuid = uuid; }
    public boolean isOwnedBy(UUID uuid) { return ownerUuid != null && ownerUuid.equals(uuid); }

    public void setOrder(int order) {
        dataTracker.set(ORDER, order);
        getNavigation().stop();
    }

    public PlayerEntity getOwner() {
        return ownerUuid == null ? null : getWorld().getPlayerByUuid(ownerUuid);
    }

    @Override
    protected Text getDefaultName() {
        return Text.translatable("entity.factions.soldier_"
                + (getFaction() == Faction.EVIL ? "evil" : "good") + "_" + getSoldierClass());
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("SoldierFaction", getFaction().ordinal());
        nbt.putInt("SoldierOrder", getOrder());
        nbt.putInt("SoldierClass", getSoldierClass());
        nbt.putInt("SoldierSquad", getSquad());
        if (ownerUuid != null) nbt.putUuid("SoldierOwner", ownerUuid);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        dataTracker.set(FACTION, nbt.getInt("SoldierFaction"));
        dataTracker.set(ORDER, nbt.getInt("SoldierOrder"));
        dataTracker.set(SOLDIER_CLASS, nbt.getInt("SoldierClass"));
        dataTracker.set(SQUAD, nbt.getInt("SoldierSquad"));
        ownerUuid = nbt.containsUuid("SoldierOwner") ? nbt.getUuid("SoldierOwner") : null;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient && age % 100 == 0 && getHealth() < getMaxHealth()) {
            heal(1.0f); // медленное восстановление
        }
    }

    // ---------- создание и отряды ----------

    /** Все бойцы игрока в загруженной части мира. */
    public static List<SoldierEntity> ownedSoldiers(ServerWorld world, UUID owner) {
        return new ArrayList<>(world.getEntitiesByType(TypeFilter.instanceOf(SoldierEntity.class),
                s -> s.isOwnedBy(owner)));
    }

    /** Место в строю: полукруг за спиной владельца, у каждого отряда свой радиус. */
    public static Vec3d formationPos(PlayerEntity owner, int index, int count, int squad) {
        double yaw = Math.toRadians(owner.getYaw());
        double bx = Math.sin(yaw), bz = -Math.cos(yaw); // «за спиной»
        double a = (index - (count - 1) / 2.0) * 0.7;
        double rx = bx * Math.cos(a) - bz * Math.sin(a);
        double rz = bx * Math.sin(a) + bz * Math.cos(a);
        double radius = 3.0 + squad * 1.8;
        return new Vec3d(owner.getX() + rx * radius, owner.getY(), owner.getZ() + rz * radius);
    }

    private static ItemStack meleeWeapon(Faction faction) {
        return new ItemStack(faction == Faction.EVIL ? Items.IRON_AXE : Items.STONE_SWORD);
    }

    private static void setMaxHealth(SoldierEntity s, double value) {
        EntityAttributeInstance inst = s.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (inst != null) inst.setBaseValue(value);
        s.setHealth((float) value);
    }

    public static SoldierEntity spawn(ServerWorld world, PlayerEntity owner, Faction faction,
                                      double x, double z, int soldierClass, int squad) {
        SoldierEntity s = FactionsMod.SOLDIER.create(world);
        if (s == null) return null;
        s.refreshPositionAndAngles(x, owner.getY(), z, owner.getYaw() + 180.0f, 0.0f);
        s.setFaction(faction);
        s.setOwnerUuid(owner.getUuid());
        s.setSoldierClass(soldierClass);
        s.setSquad(squad);
        s.setPersistent();

        switch (s.getSoldierClass()) {
            case CLASS_RIFLEMAN -> {
                setMaxHealth(s, 24.0);
                ItemStack gun = TaczCompat.createRandomGun(world.getRandom());
                s.equipStack(EquipmentSlot.MAINHAND, gun.isEmpty() ? meleeWeapon(faction) : gun);
            }
            case CLASS_MEDIC -> setMaxHealth(s, 24.0);
            default -> {
                setMaxHealth(s, 40.0);
                s.equipStack(EquipmentSlot.MAINHAND, meleeWeapon(faction));
                s.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
            }
        }
        s.setEquipmentDropChance(EquipmentSlot.MAINHAND, 1.0f);
        s.setEquipmentDropChance(EquipmentSlot.HEAD, 1.0f);
        world.spawnEntity(s);
        return s;
    }

    // ---------- союзники и враги ----------

    public boolean isAlly(LivingEntity e) {
        if (e instanceof PlayerEntity p) return FactionsMod.getFaction(p) == getFaction();
        if (e instanceof SoldierEntity s) return s.getFaction() == getFaction();
        return getFaction() == Faction.GOOD ? FactionsMod.isGoodMob(e) : FactionsMod.isEvilMob(e);
    }

    private boolean isEnemy(LivingEntity e) {
        if (getSoldierClass() == CLASS_MEDIC) return false; // медик не ищет драки
        if (e == this || !e.isAlive()) return false;
        return getFaction() == Faction.GOOD ? FactionsMod.isGoodSideEnemy(e) : FactionsMod.isEvilSideEnemy(e);
    }

    // ---------- ИИ ----------

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new GunGoal(this, this::isEnemy, () -> getOrder() == ORDER_FOLLOW, 1.0));
        goalSelector.add(2, new HealAlliesGoal());
        goalSelector.add(3, new MeleeAttackGoal(this, 1.1, true) {
            @Override
            public boolean canStart() {
                LivingEntity t = getTarget();
                boolean close = t != null && squaredDistanceTo(t) < 9.0;
                return (getOrder() == ORDER_FOLLOW || close) && super.canStart();
            }
        });
        goalSelector.add(4, new FollowOwnerGoal());
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(7, new LookAroundGoal(this));

        targetSelector.add(1, new DefendOwnerGoal());
        targetSelector.add(2, new RevengeGoal(this));
        targetSelector.add(3, new ActiveTargetGoal<>(this, LivingEntity.class, 10, true, false, this::isEnemy));
    }

    /** Медик лечит раненых союзников. */
    private class HealAlliesGoal extends Goal {
        private LivingEntity patient;
        private int cooldown;

        HealAlliesGoal() { setControls(EnumSet.of(Control.MOVE, Control.LOOK)); }

        private static boolean hurt(LivingEntity e) {
            return e.isAlive() && e.getHealth() < e.getMaxHealth() - 0.5f;
        }

        @Override
        public boolean canStart() {
            if (getSoldierClass() != CLASS_MEDIC || age % 10 != 0) return false;
            double range = getOrder() == ORDER_FOLLOW ? 16.0 : 5.0;
            Box box = getBoundingBox().expand(range);
            patient = getWorld().getEntitiesByClass(LivingEntity.class, box,
                            e -> e != SoldierEntity.this && hurt(e) && isAlly(e))
                    .stream()
                    .min(Comparator.comparingDouble(e -> e.getHealth() / e.getMaxHealth()))
                    .orElse(null);
            return patient != null;
        }

        @Override
        public boolean shouldContinue() {
            return patient != null && hurt(patient) && squaredDistanceTo(patient) < 400.0;
        }

        @Override
        public void start() { cooldown = 0; }

        @Override
        public void stop() {
            getNavigation().stop();
            patient = null;
        }

        @Override
        public boolean shouldRunEveryTick() { return true; }

        @Override
        public void tick() {
            if (patient == null) return;
            getLookControl().lookAt(patient, 30.0f, 30.0f);
            double dist = distanceTo(patient);
            if (dist > 3.0 && getOrder() == ORDER_FOLLOW) {
                getNavigation().startMovingTo(patient, 1.2);
            } else {
                getNavigation().stop();
            }
            if (dist <= 5.0 && --cooldown <= 0) {
                patient.heal(4.0f);
                cooldown = 40;
                if (getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(ParticleTypes.HEART, patient.getX(), patient.getBodyY(0.8), patient.getZ(),
                            3, 0.3, 0.3, 0.3, 0.0);
                }
            }
        }
    }

    /** Идёт за владельцем, занимая своё место в строю своего отряда. */
    private class FollowOwnerGoal extends Goal {
        private PlayerEntity owner;
        private Vec3d slot = Vec3d.ZERO;
        private int recalc;

        FollowOwnerGoal() { setControls(EnumSet.of(Control.MOVE, Control.LOOK)); }

        @Override
        public boolean canStart() {
            owner = getOwner();
            return getOrder() == ORDER_FOLLOW && owner != null && !owner.isSpectator()
                    && getTarget() == null && squaredDistanceTo(owner) > 36.0;
        }

        @Override
        public void start() {
            recalc = 0;
            updateSlot();
        }

        @Override
        public boolean shouldContinue() {
            return owner != null && owner.isAlive() && getOrder() == ORDER_FOLLOW && getTarget() == null
                    && squaredDistanceTo(slot.x, slot.y, slot.z) > 2.25;
        }

        @Override
        public void stop() { getNavigation().stop(); }

        private void updateSlot() {
            List<SoldierEntity> squad = ownedSoldiers((ServerWorld) getWorld(), ownerUuid);
            squad.removeIf(s -> s.getOrder() != ORDER_FOLLOW || s.getSquad() != getSquad());
            squad.sort(Comparator.comparing(Entity::getUuid));
            int i = Math.max(0, squad.indexOf(SoldierEntity.this));
            slot = formationPos(owner, i, Math.max(1, squad.size()), getSquad());
        }

        @Override
        public void tick() {
            getLookControl().lookAt(owner, 10.0f, getMaxLookPitchChange());
            if (--recalc > 0) return;
            recalc = 10;
            updateSlot();
            if (squaredDistanceTo(owner) >= 900.0) {
                refreshPositionAndAngles(slot.x, slot.y, slot.z, getYaw(), getPitch());
                getNavigation().stop();
            } else {
                getNavigation().startMovingTo(slot.x, slot.y, slot.z, 1.1);
            }
        }
    }

    private class DefendOwnerGoal extends Goal {
        private LivingEntity victim;

        DefendOwnerGoal() { setControls(EnumSet.of(Control.TARGET)); }

        @Override
        public boolean canStart() {
            if (getSoldierClass() == CLASS_MEDIC) return false;
            PlayerEntity owner = getOwner();
            if (owner == null) return false;
            LivingEntity c = owner.getAttacker();
            if (c == null || !c.isAlive()) c = owner.getAttacking();
            if (c == null || !c.isAlive() || c == SoldierEntity.this || isAlly(c)) return false;
            victim = c;
            return true;
        }

        @Override
        public void start() { setTarget(victim); }
    }

    // ---------- управление игроком ----------

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
        if (getWorld().isClient) return ActionResult.SUCCESS;

        if (ownerUuid == null && FactionsMod.getFaction(player) == getFaction()) {
            ownerUuid = player.getUuid();
        }
        if (!isOwnedBy(player.getUuid())) {
            player.sendMessage(Text.translatable("message.factions.not_yours"), true);
            return ActionResult.SUCCESS;
        }

        ItemStack held = player.getStackInHand(hand);
        if (held.isEmpty()) {
            if (player.isSneaking()) {
                returnAllGear(player);
                player.sendMessage(Text.translatable("message.factions.unequipped"), true);
            } else {
                int next = getOrder() == ORDER_FOLLOW ? ORDER_HOLD : ORDER_FOLLOW;
                setOrder(next);
                player.sendMessage(Text.translatable(next == ORDER_FOLLOW
                        ? "message.factions.order_follow" : "message.factions.order_hold"), true);
            }
            return ActionResult.SUCCESS;
        }

        EquipmentSlot slot = slotFor(held);
        ItemStack old = getEquippedStack(slot);
        equipStack(slot, held.copyWithCount(1));
        setEquipmentDropChance(slot, 1.0f);
        if (!player.isCreative()) held.decrement(1);
        if (!old.isEmpty()) player.getInventory().offerOrDrop(old);
        player.sendMessage(Text.translatable("message.factions.equipped"), true);
        return ActionResult.SUCCESS;
    }

    private static EquipmentSlot slotFor(ItemStack stack) {
        if (stack.getItem() instanceof ArmorItem armor) return armor.getSlotType();
        if (stack.isOf(Items.SHIELD)) return EquipmentSlot.OFFHAND;
        return EquipmentSlot.MAINHAND;
    }

    private void returnAllGear(PlayerEntity player) {
        EquipmentSlot[] slots = {EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
                EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot s : slots) {
            ItemStack stack = getEquippedStack(s);
            if (!stack.isEmpty()) {
                player.getInventory().offerOrDrop(stack);
                equipStack(s, ItemStack.EMPTY);
            }
        }
    }
}
